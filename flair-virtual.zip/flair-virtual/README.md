# Flair Virtual

A front-end mockup for a virtual airline website, built as static HTML/CSS/JS for GitHub Pages.

## Structure

```
index.html          Home page
pages/fleet.html     Fleet specs
pages/routes.html    Route network (searchable/filterable table + map graphic)
pages/ranks-awards.html   Rank structure + awards
pages/community.html Events, leaderboards, gallery, staff directory (tabbed)
pages/portal.html    Login/register UI + static dashboard preview
pages/about.html     About + required disclaimer
css/style.css        Shared design system (colors, type, components)
js/main.js           Shared behavior (nav, dark mode, reveal animations, counters)
```

## Deploying to GitHub Pages

1. Push this folder's contents to the root of a GitHub repo (or to a `docs/` folder).
2. In the repo settings → **Pages**, set the source to the branch/folder you used.
3. Your site will publish at `https://<username>.github.io/<repo-name>/`.

No build step is required — it's plain HTML/CSS/JS.

## What's real vs. placeholder

This is a **visual front-end only**. Nothing here talks to a database or server:

- **Login/registration** (`portal.html`) — UI only, does not authenticate anyone.
- **Dashboard, flight history, pilot ID** — static sample data.
- **Route table** — filters/sorts a hardcoded JS array, not a live schedule.
- **ACARS, live flight tracking, admin panel, ticketing, email verification** — not built. These need a real backend (database + auth + a tracking client that talks to your sim) and are outside the scope of a static site.
- **Route map** — a stylized SVG graphic, not an interactive pan/zoom map. Swap in a real mapping library (e.g. Leaflet + a GeoJSON route dataset) if you want it fully interactive.
- **Discord "live" status/member counts** — static numbers. Real live status needs the Discord widget API or a bot.

## Branding

Colors and type are an **original identity** (marigold yellow / near-black / runway green), inspired by the tone of Flair's real-world branding rather than a reproduction of their actual logo or livery. Swap in the authorized logo files and official brand colors/liveries wherever you see the "✈" placeholder mark and the CSS custom properties in `css/style.css` (`--marigold`, `--ink`, etc.).

## Images

Homepage/fleet/gallery images are hotlinked from Unsplash for the preview. For a production deploy, download and self-host images (or your own screenshots) in `assets/img/` and update the `src` attributes — hotlinking to Unsplash isn't reliable long-term and won't reflect your actual liveries/community.
